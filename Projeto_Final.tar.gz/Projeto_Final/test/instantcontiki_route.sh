#configure for host if broker is on host
route add -net 172.16.255.0 netmask 255.255.255.0 gw 172.16.220.128
